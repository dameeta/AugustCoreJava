package mycollections;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Queue newqueue=new LinkedList();
		newqueue.add("five");
		newqueue.add(5);
		newqueue.add(false);
		newqueue.add(1.1);
		newqueue.add(33435545);
		newqueue.add(33435545);

		System.out.println(newqueue);
		System.out.println(newqueue.size());
		System.out.println(newqueue.element());
		System.out.println(newqueue);
		newqueue.remove();
		System.out.println(newqueue);
		newqueue.remove();
		System.out.println(newqueue);
	}

}
